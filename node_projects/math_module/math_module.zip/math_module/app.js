var math_module = require('./mathlib')();
math_module.add(5,6);
math_module.multiply(5,6);
math_module.square(6);
math_module.random(0,100);
